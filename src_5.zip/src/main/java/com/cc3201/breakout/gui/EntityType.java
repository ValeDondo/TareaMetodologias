package com.cc3201.breakout.gui;

/**
 * 
 * @author vale.
 *
 */

public enum EntityType {

  BAT,BALL,BRICK, WALL;
    
}
